#pragma once
#include <iostream>
#include "templateGrafos.h"   //Calabozo es un Grafo de cuartos
#include "Cuarto.h"    //Calabozo contiene cuartos
using namespace std;

class Dungeon {
private:
	Grafo<Cuarto> rooms;

public:
	Dungeon() {
	}

	~Dungeon() {
		rooms.borrarGrafo();
	}

	bool createDungeon(const string& fileName);  //Complejidad de los metodos: O(n) 
	bool createRoom(unsigned int indexCuarto, Monstruo monster);  
	void imprimeCuartos();
	unsigned int getSize();   //Complejidad: O(1)
};
