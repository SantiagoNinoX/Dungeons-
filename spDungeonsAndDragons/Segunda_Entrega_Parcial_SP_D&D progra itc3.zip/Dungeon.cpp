#include <iostream>
#include "Dungeon.h"
using namespace std;

bool Dungeon::createDungeon(const string& fileName) {
	return rooms.cargarArchivo(fileName);
}

void Dungeon::imprimeCuartos() {
	rooms.imprimirGrafo();
}

bool Dungeon::createRoom(unsigned int indexCuarto, Monstruo monster) {
	Cuarto recamara;
	recamara.setMonstruo(monster);
	return rooms.setVertex(indexCuarto, recamara);
}

unsigned int Dungeon::getSize() {
	return rooms.getSizeGrafo();
}