#include <iostream>
#include "Dungeon.h"
using namespace std;

void Dungeon::imprimeCuartos() {
	rooms.imprimeListaDoble();
}

bool Dungeon::createRoom(Monstruo monster) {
	Cuarto c;
	c.setMonstruo(monster);
	rooms.insertaEnOrdenDoble(c);
	return true;
}