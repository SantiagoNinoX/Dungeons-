#include <iostream>
#include "Catalogo.h"
#include "Dungeon.h"
using namespace std;
#define NUM_CUARTOS 20

int main() {
	Catalogo miCatalogo;
	Dungeon  miDungeon;

	if (!miCatalogo.loadFromCSV("monsters.csv")) {
		cout << "No se pudo crear el catalogo" << endl;
		return 0;
	}

	cout << "Creando Dungeon ..." << endl;
	for (int c = 0; c < NUM_CUARTOS; c++) {
		Monstruo* pMonster = nullptr;
		Monstruo copiaMonstruo;
		pMonster = miCatalogo.selectRandomMonster();
		if (!pMonster) {
			cout << "No se pudo obtener un monstruo del catalogo" << endl;
			return 0;
		}
		copiaMonstruo = *pMonster;
		if (!miDungeon.createRoom(copiaMonstruo)) {
			cout << "No se pudo insertar cuarto con monstruo al calabozo" << endl;
			return 0;
		}
	}
	miDungeon.imprimeCuartos();
	return 0;
}