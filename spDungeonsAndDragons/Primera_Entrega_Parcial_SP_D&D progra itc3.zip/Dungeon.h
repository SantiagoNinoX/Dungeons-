#pragma once
#include <iostream>
#include "TemplateListasDobles.h"   //Calabozo es una Lista Doblemente Ligada de cuartos
#include "Cuarto.h"    //Calabozo contiene cuartos
using namespace std;

class Dungeon {
private:
	ListaDoble<Cuarto> rooms;

public:
	Dungeon() {
	}

	~Dungeon() {
		rooms.deleteListaDoble();
	}

	void imprimeCuartos();   //Complejidad de los metodos: O(n)
	bool createRoom(Monstruo monster);  
};
